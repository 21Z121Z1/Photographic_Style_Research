XDRemux 摄影风格与纹理风格联合生成测试包。photos/ 是完整尺寸 HDR 产品输出。先导入 portrait-02（含三组人物统计）、portrait-01、hr-01 与 LHDR 样张。核对激活、控件响应、HDR、保存及重新打开。此前用户已确认 SDR 研究候选能激活；本包新 HDR 文件尚待设备测试。文件来源与 SHA 见 FILES.json。
