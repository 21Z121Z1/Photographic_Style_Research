# XDRemux 真实样张 Texture 导入测试

将 originals/ 中的 HEIC 原件导入此前成功激活的同一台设备。controls/ 是同一编码主图的普通对照，previews/ 仅为逐人原生效果烘焙图。derived/ 是明确标识的双人拼接及尺寸压力用例。

建议先测 Samsung JPEG 人像、vivo 店内多人场景、OPPO portrait-02、OPPO hr-01 无人像，以及 derived/derived-two-fixture-faces.heic。随后批量测试 originals/。

每张输出均为新建的 SDR 编辑副本，默认长边 1024；derived/ 的尺寸变体另标 512/2048。原照片 HDR 和动态视频没有带入该副本。不要把 previews/ 当作可编辑候选。

记录是否激活、纹理/颗粒与柔肤控件是否产生变化，以及修改保存后重新打开是否保留。小脸或无人物区域可能没有某项人物效果，逐图真实原生输出见 receipts/ 和 FILES.json。

本包是新的 fixture 输出，尚无设备激活反馈。此前用户已确认的 NASA 候选 SHA 为 a7ac5d0dc8721e0cac4db6bfec153864f96fc83f406adeedc2036bc6f0543a7b；它的结果不自动适用于这些新文件。
